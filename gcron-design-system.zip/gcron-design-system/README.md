# Sistema de diseño CTS — extraído de G-Cron

Estilos, tokens, fuentes, logos y componentes que usa G-Cron, para construir la librería de estilos de Industrias CTS.

**Empieza por `styleguide.html`.** Ábrelo en el navegador con un servidor local, no con doble clic (ver «Cómo verlo»). Muestra los colores, la tipografía, los espacios, los componentes y los patrones, en claro y en oscuro.

## Contenido

| Carpeta / archivo | Qué es |
|---|---|
| `styleguide.html` | Guía visual navegable, con el botón Claro / Oscuro |
| `tokens/tokens.css` | **Fuente de verdad**: variables CSS de marca (`--cts-*`) y roles semánticos (`--primary`, `--muted`…) en claro (`:root`) y oscuro (`.dark`) |
| `tokens/tokens.json` | Los mismos tokens en JSON, para Figma (Tokens Studio), Style Dictionary, apps móviles, etc. Incluye la paleta de entregas, los colores de estado y los tipos de cambio del historial |
| `tokens/fonts.css` | `@font-face` de Titillium Web y Conthrax |
| `tokens/tailwind-theme.css` | Tema de Tailwind CSS v4 (`@theme`): clases como `bg-primary`, `text-cts-blue`, `rounded-cts-md`, `shadow-cts-lg`, `font-heading` |
| `tokens/base.css` | Escala tipográfica base (h1–h6, p) |
| `fonts/` | Archivos de las fuentes (TTF / OTF) |
| `brand/` | Logo CTS (PNG), logo e ícono de G-Cron (SVG) |
| `components/cts/` | Componentes React de marca: `Button`, `Badge`, `Input`, `Card`, `Typography` |
| `components/ui/` | Primitivas React sobre Base UI (estilo shadcn/ui): dialog, dropdown-menu, select, popover, tooltip, switch, sheet, calendar, avatar… |
| `components/lib/` | `cn()` (clsx + tailwind-merge) y la paleta de colores de entregas |
| `components/examples/` | Piezas propias de G-Cron como referencia (íconos de tipo de cambio, leyenda del Gantt, barra de progreso) |
| `patterns/` | CSS de patrones: barras del Gantt y marcador de hoy, barras de desplazamiento CTS, animaciones |

## Uso rápido

### Solo CSS (cualquier proyecto)

```html
<link rel="stylesheet" href="tokens/tokens.css">
<style>
  .boton { background: var(--primary); color: var(--primary-foreground); border-radius: var(--cts-radius-md); }
</style>
```

Para el modo oscuro, agrega la clase `dark` al `<html>`.

### React + Tailwind CSS v4 (como G-Cron)

```css
@import "tailwindcss";
@import "./tokens/tokens.css";
@import "./tokens/tailwind-theme.css";
@import "./tokens/base.css";
```

Los componentes de `components/` esperan el alias `@/` (`@/lib/utils`, `@/components/ui/...`). Necesitan estas dependencias:

```
react@19  tailwindcss@4  @base-ui/react  class-variance-authority  clsx  tailwind-merge  lucide-react  tw-animate-css
```

Además, `components/ui/calendar.tsx` usa `react-day-picker` y `components/ui/form.tsx` usa `react-hook-form`.

## Decisiones clave

- **Azul CTS `#0065BB`** es el color de acción. En modo oscuro el primario pasa a **`#89AEDC`**, porque `#0065BB` sobre la superficie oscura `#283D63` solo da 1,9:1 de contraste.
- **Ámbar `#D97706` y rojo `#DC2626`** se reservan para las alertas «en riesgo» y «atrasada». Por eso la paleta de entregas no tiene naranja (se cambió por turquesa `#0D9488`).
- **Tipografía:** Conthrax solo en títulos; Titillium Web en todo lo demás (400 / 600 / 700).
- **Sombras** con tinte azul CTS en claro y negras en oscuro.
- **Fondo de página** `#D0DCF0` detrás de tarjetas blancas; en oscuro, página `#192945` con tarjetas `#283D63`.
- **Paleta de entregas** en orden de uso: Azul CTS, Turquesa, Verde, Violeta, Gris oscuro, Frambuesa, Azul claro, Amarillo. `deliveryColors.ts` genera variantes más claras y más oscuras hasta 14 colores.

## Cómo verlo

`styleguide.html` carga `tokens/tokens.css` y las fuentes con rutas relativas. Algunos navegadores bloquean las fuentes al abrir el archivo con doble clic, así que conviene usar un servidor local desde esta carpeta:

```bash
python3 -m http.server 8080
```

Luego abre `http://localhost:8080/styleguide.html`.

## Notas

- **Licencia de Conthrax:** es una fuente comercial de Typodermic. Confirma que la licencia de la empresa cubre su uso en web y apps antes de distribuirla. Titillium Web es libre (SIL Open Font License).
- Los tokens se generaron desde `frontend/src/styles/globals.css` de G-Cron. Si la app cambia, vuelve a generarlos desde ahí.
