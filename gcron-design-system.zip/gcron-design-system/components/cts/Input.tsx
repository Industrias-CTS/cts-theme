import React from 'react'
import { cn } from '@/lib/utils'

export type InputState = 'default' | 'error' | 'success'
export type InputSize = 'sm' | 'md' | 'lg'

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label?: string
  hint?: string
  state?: InputState
  message?: string
  size?: InputSize
  leadingIcon?: React.ReactNode
  trailingIcon?: React.ReactNode
}

const stateStyles: Record<InputState, { border: string; message: string }> = {
  default: {
    border:  'border-cts-border focus:border-cts-border-focus focus:ring-2 focus:ring-cts-primary/20',
    message: 'text-cts-text-muted',
  },
  error: {
    border:  'border-cts-error focus:border-cts-error focus:ring-2 focus:ring-cts-error/20',
    message: 'text-cts-error',
  },
  success: {
    border:  'border-cts-success focus:border-cts-success focus:ring-2 focus:ring-cts-success/20',
    message: 'text-cts-success',
  },
}

const sizeStyles: Record<InputSize, { input: string; icon: string }> = {
  sm: { input: 'px-3 py-1.5 text-sm',   icon: 'text-sm'  },
  md: { input: 'px-4 py-2.5 text-base', icon: 'text-base' },
  lg: { input: 'px-4 py-3.5 text-lg',   icon: 'text-lg'  },
}

export function Input({
  label,
  hint,
  state = 'default',
  message,
  size = 'md',
  leadingIcon,
  trailingIcon,
  disabled,
  id,
  required,
  className = '',
  ...props
}: InputProps) {
  const inputId = id ?? label?.toLowerCase().replace(/\s+/g, '-')

  return (
    <div className="flex flex-col gap-1.5">
      {(label || hint) && (
        <div className="flex flex-col gap-0.5">
          {label && (
            <label htmlFor={inputId} className="font-body font-bold text-sm text-cts-text">
              {label}
              {required && (
                <span className="text-cts-error ml-1" aria-hidden="true">*</span>
              )}
            </label>
          )}
          {hint && (
            <span className="font-body text-xs text-cts-text-muted">{hint}</span>
          )}
        </div>
      )}

      <div className="relative flex items-center">
        {leadingIcon && (
          <span
            className={`absolute left-3 text-muted-foreground pointer-events-none ${sizeStyles[size].icon}`}
            aria-hidden="true"
          >
            {leadingIcon}
          </span>
        )}

        <input
          id={inputId}
          required={required}
          disabled={disabled}
          className={cn(
            'w-full font-body rounded-md border bg-cts-bg dark:bg-muted/30 text-cts-text',
            'transition-all duration-[200ms] ease-[cubic-bezier(0.4,0,0.2,1)]',
            'placeholder:text-cts-text-disabled/70 dark:placeholder:text-foreground/40 focus:outline-none',
            'disabled:bg-cts-bg-alt disabled:text-cts-text-disabled disabled:cursor-not-allowed',
            stateStyles[state].border,
            sizeStyles[size].input,
            leadingIcon  && 'pl-10',
            trailingIcon && 'pr-10',
            className,
          )}
          aria-invalid={state === 'error'}
          aria-describedby={message ? `${inputId}-message` : undefined}
          {...props}
        />

        {trailingIcon && (
          <span
            className={`absolute right-3 text-muted-foreground pointer-events-none ${sizeStyles[size].icon}`}
            aria-hidden="true"
          >
            {trailingIcon}
          </span>
        )}
      </div>

      {message && (
        <span
          id={`${inputId}-message`}
          className={`font-body text-xs ${stateStyles[state].message}`}
          role={state === 'error' ? 'alert' : undefined}
        >
          {message}
        </span>
      )}
    </div>
  )
}
