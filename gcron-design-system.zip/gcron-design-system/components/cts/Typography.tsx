import { cn } from "@/lib/utils";
import type { HTMLAttributes, ElementType } from "react";

type Variant = "h1" | "h2" | "h3" | "h4" | "subtitle" | "body-lg" | "body" | "body-sm" | "label" | "caption";
type Color   = "default" | "primary" | "muted";

const variantClasses: Record<Variant, string> = {
  h1:        "font-display font-bold text-5xl leading-tight",
  h2:        "font-display font-bold text-4xl leading-tight",
  h3:        "font-display font-semibold text-3xl leading-snug",
  h4:        "font-display font-semibold text-2xl leading-snug",
  subtitle:  "font-display font-normal text-xl leading-snug",
  "body-lg": "font-body font-normal text-lg leading-relaxed",
  body:      "font-body font-normal text-base leading-relaxed",
  "body-sm": "font-body font-normal text-sm leading-normal",
  label:     "font-body font-bold text-sm leading-normal",
  caption:   "font-body font-normal text-xs leading-normal",
};

const colorClasses: Record<Color, string> = {
  default: "text-foreground",
  primary: "text-primary",
  muted:   "text-muted-foreground",
};

const defaultTag: Record<Variant, ElementType> = {
  h1:        "h1",
  h2:        "h2",
  h3:        "h3",
  h4:        "h4",
  subtitle:  "p",
  "body-lg": "p",
  body:      "p",
  "body-sm": "p",
  label:     "span",
  caption:   "span",
};

interface TypographyProps extends HTMLAttributes<HTMLElement> {
  variant?: Variant;
  color?:   Color;
  as?:      ElementType;
}

export function Typography({
  variant = "body",
  color   = "default",
  as,
  className,
  children,
  ...props
}: TypographyProps) {
  const Tag = as ?? defaultTag[variant];
  return (
    <Tag
      className={cn(variantClasses[variant], colorClasses[color], className)}
      {...props}
    >
      {children}
    </Tag>
  );
}
