import React from 'react'
import { cn } from '@/lib/utils'

export type BadgeVariant = 'default' | 'success' | 'warning' | 'error' | 'info' | 'muted'
export type BadgeSize = 'sm' | 'md' | 'lg'

export interface BadgeProps {
  variant?: BadgeVariant
  size?: BadgeSize
  dot?: boolean
  children: React.ReactNode
  className?: string
}

const variantStyles: Record<BadgeVariant, string> = {
  default: 'bg-cts-primary/10 text-cts-primary border border-cts-primary/20',
  success: 'bg-cts-success/10 text-cts-success border border-cts-success/20',
  warning: 'bg-cts-warning/10 text-cts-warning border border-cts-warning/20',
  error:   'bg-cts-error/10 text-cts-error border border-cts-error/20',
  info:    'bg-cts-info/10 text-cts-primary border border-cts-info/20',
  muted:   'bg-cts-bg-alt text-cts-text-muted border border-cts-border',
}

const dotStyles: Record<BadgeVariant, string> = {
  default: 'bg-cts-primary',
  success: 'bg-cts-success',
  warning: 'bg-cts-warning',
  error:   'bg-cts-error',
  info:    'bg-cts-info',
  muted:   'bg-cts-text-muted',
}

const sizeStyles: Record<BadgeSize, string> = {
  sm: 'px-1.5 py-0.5 text-xs gap-1',
  md: 'px-2.5 py-1 text-xs gap-1.5',
  lg: 'px-3 py-1.5 text-sm gap-1.5',
}

export function Badge({
  variant = 'default',
  size = 'md',
  dot = false,
  children,
  className,
}: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center font-body font-semibold rounded-full whitespace-nowrap',
        variantStyles[variant],
        sizeStyles[size],
        className,
      )}
    >
      {dot && (
        <span
          className={cn(
            'shrink-0 rounded-full',
            dotStyles[variant],
            size === 'lg' ? 'w-2 h-2' : 'w-1.5 h-1.5',
          )}
          aria-hidden="true"
        />
      )}
      {children}
    </span>
  )
}
