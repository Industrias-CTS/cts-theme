import React from 'react'

export type CardVariant = 'default' | 'elevated' | 'outlined' | 'filled'

export interface CardProps {
  variant?: CardVariant
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export interface CardHeaderProps {
  title: string
  subtitle?: string
  action?: React.ReactNode
  className?: string
}

export interface CardBodyProps {
  children: React.ReactNode
  className?: string
  noPadding?: boolean
}

export interface CardFooterProps {
  children: React.ReactNode
  className?: string
}

const variantStyles: Record<CardVariant, string> = {
  default:  'bg-cts-bg border border-cts-border shadow-cts-sm',
  elevated: 'bg-cts-bg border-0 shadow-cts-lg',
  outlined: 'bg-cts-bg border-2 border-cts-primary shadow-none',
  filled:   'bg-cts-primary border-0 shadow-cts-md',
}

export function Card({ variant = 'default', children, className = '', onClick }: CardProps) {
  const isInteractive = !!onClick

  return (
    <div
      className={[
        'rounded-lg overflow-hidden',
        'transition-shadow duration-[200ms] ease-[cubic-bezier(0.4,0,0.2,1)]',
        variantStyles[variant],
        isInteractive ? 'cursor-pointer hover:shadow-cts-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cts-primary' : '',
        className,
      ].filter(Boolean).join(' ')}
      onClick={onClick}
      onKeyDown={isInteractive ? (e) => e.key === 'Enter' && onClick?.() : undefined}
      role={isInteractive ? 'button' : undefined}
      tabIndex={isInteractive ? 0 : undefined}
    >
      {children}
    </div>
  )
}

export function CardHeader({ title, subtitle, action, className = '' }: CardHeaderProps) {
  return (
    <div
      className={[
        'flex items-start justify-between px-6 py-4',
        'border-b border-cts-border/50',
        className,
      ].filter(Boolean).join(' ')}
    >
      <div className="min-w-0 flex-1">
        <h3 className="font-display font-bold text-lg text-cts-text truncate">
          {title}
        </h3>
        {subtitle && (
          <p className="font-body text-sm text-cts-text-muted mt-0.5">{subtitle}</p>
        )}
      </div>
      {action && <div className="ml-4 shrink-0">{action}</div>}
    </div>
  )
}

export function CardBody({ children, className = '', noPadding = false }: CardBodyProps) {
  return (
    <div className={[noPadding ? '' : 'px-6 py-4', className].filter(Boolean).join(' ')}>
      {children}
    </div>
  )
}

export function CardFooter({ children, className = '' }: CardFooterProps) {
  return (
    <div
      className={[
        'px-6 py-4',
        'border-t border-cts-border/50',
        'bg-cts-bg-alt',
        className,
      ].filter(Boolean).join(' ')}
    >
      {children}
    </div>
  )
}
