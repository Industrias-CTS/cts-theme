import { cn } from "@/lib/utils";

/** Thin horizontal bar with the progress percentage. `percent` null = nothing to measure. */
export function ProgressBar({
  percent,
  color,
  showLabel = true,
  className,
  barClassName,
  labelClassName,
}: {
  percent: number | null;
  color?: string;
  showLabel?: boolean;
  className?: string;
  /** Overrides for the track (e.g. a taller bar) and the percentage text */
  barClassName?: string;
  labelClassName?: string;
}) {
  if (percent === null) return <span className="text-xs text-muted-foreground">—</span>;
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div
        className={cn("h-1.5 w-full min-w-10 overflow-hidden rounded-full bg-muted", barClassName)}
        role="progressbar"
        aria-valuenow={percent}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`Avance ${percent} %`}
      >
        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${percent}%`, backgroundColor: color }} />
      </div>
      {showLabel && <span className={cn("text-xs tabular-nums text-muted-foreground", labelClassName)}>{percent}%</span>}
    </div>
  );
}
