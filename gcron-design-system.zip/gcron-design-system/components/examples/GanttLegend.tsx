import { useDisplayColor } from "@/hooks/useDisplayColor";

/** A swatch of the Gantt bars: `solid` is the filled share (0–1), `alert` adds the red / amber border. */
function Swatch({ solid, alert, color }: { solid: number; alert?: "late" | "risk"; color: string }) {
  return (
    <span
      aria-hidden
      className="gantt-bar relative inline-flex h-3 w-5 overflow-hidden rounded-[3px]"
      style={{ ["--bar" as string]: color }}
    >
      {solid > 0 && <span className="gantt-bar-solid" style={{ flex: solid }} />}
      {solid < 1 && <span className="gantt-bar-striped" style={{ flex: 1 - solid }} />}
      <span className={alert ? `absolute inset-0 rounded-[3px] ${alert === "late" ? "gantt-bar-late" : "gantt-bar-risk"}` : "gantt-bar-border absolute inset-0 rounded-[3px]"} />
    </span>
  );
}

/**
 * Explains the bars of the Gantt: solid = done, stripes = still missing. "Atrasada" and "En riesgo" only
 * show when some bar is in that state; a late task is drawn as not started (all stripes) and an at-risk one
 * as half done, so neither looks like finished work.
 */
export function GanttLegend({ late = false, risk = false }: { late?: boolean; risk?: boolean }) {
  const dc = useDisplayColor();
  const blue = dc("#0065BB");
  return (
    <div className="mr-auto flex items-center gap-3 text-xs text-muted-foreground" aria-label="Leyenda del diagrama">
      <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
        <Swatch solid={1} color={blue} />
        Avance
      </span>
      <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
        <Swatch solid={0} color={blue} />
        Pendiente
      </span>
      {late && (
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
          <Swatch solid={0} alert="late" color={blue} />
          Atrasada
        </span>
      )}
      {risk && (
        <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
          <Swatch solid={0.5} alert="risk" color={blue} />
          En riesgo
        </span>
      )}
    </div>
  );
}
