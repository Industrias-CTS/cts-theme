import type { ChangeKind } from "@/lib/activityFilters";

// Filled glyphs (Material "edit", "add", "delete", "history", "file_download"), same look as the rest of the history UI
const PATHS: Record<ChangeKind, string> = {
  edit: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z",
  add: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z",
  remove: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z",
  restore:
    "M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.95 8.95 0 0 0 13 21a9 9 0 0 0 0-18m-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8z",
  export: "M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z",
};

const COLOR: Record<ChangeKind, string> = {
  add: "text-emerald-500",
  edit: "text-amber-500",
  remove: "text-destructive",
  restore: "text-violet-500",
  export: "text-sky-500",
};

/** Icon of a kind of change: green plus (created), amber pencil (edited), red bin (removed), violet clock (restored), blue download (exported). */
export function ChangeKindIcon({ kind, className = "h-4 w-4" }: { kind: ChangeKind; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={`${className} fill-current ${COLOR[kind]}`} aria-hidden focusable="false">
      <path d={PATHS[kind]} />
    </svg>
  );
}
