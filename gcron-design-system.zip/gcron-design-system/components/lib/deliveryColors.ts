/**
 * Colors of the deliveries. The first 8 are the ones the picker offers: the CTS blue, grey and
 * light blue, the CTS success green, turquoise and 3 more that are easy to tell apart from them
 * (violet, raspberry, yellow). No orange: amber/red outlines mean "en riesgo"/"atrasada" in the Gantt. New deliveries take them in this order; after
 * them come darker and lighter versions of the same colors that still look different from every
 * earlier one, up to 14, before starting over. Keep in sync with
 * backend/src/projects/delivery-colors.ts (both are tested against the same list) and the
 * 20261010140000_delivery_brand_colors migration.
 */
export const DELIVERY_BASE_COLORS = [
  { hex: "#0065BB", name: "Azul CTS" },
  { hex: "#0D9488", name: "Turquesa" },
  { hex: "#16A34A", name: "Verde" },
  { hex: "#7C4DBA", name: "Violeta" },
  { hex: "#646464", name: "Gris oscuro" },
  { hex: "#C2255C", name: "Frambuesa" },
  { hex: "#89AEDC", name: "Azul claro" },
  { hex: "#E0B400", name: "Amarillo" },
] as const;

const hex2 = (n: number) => Math.round(n).toString(16).padStart(2, "0").toUpperCase();
const channel = (hex: string, i: number) => parseInt(hex.slice(1 + i * 2, 3 + i * 2), 16);

/** `hex` mixed with `target` ("#FFFFFF" lightens, "#000000" darkens); `amount` 0-1 is how much of the target. */
export function mixColor(hex: string, target: string, amount: number): string {
  return `#${[0, 1, 2].map((i) => hex2(channel(hex, i) + (channel(target, i) - channel(hex, i)) * amount)).join("")}`;
}

/** CIE L*a*b* of a #RRGGBB color (D65), the space where distance matches what the eye sees. */
function toLab(hex: string): [number, number, number] {
  const lin = (v: number) => {
    const c = v / 255;
    return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  };
  const [r, g, b] = [0, 1, 2].map((i) => lin(channel(hex, i)));
  const f = (t: number) => (t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116);
  const fx = f((r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047);
  const fy = f(r * 0.2126 + g * 0.7152 + b * 0.0722);
  const fz = f((r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883);
  return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
}

/** How different two colors look (CIE76 ΔE): under ~20 they are hard to tell apart. */
export function colorDifference(a: string, b: string): number {
  const [la, aa, ba] = toLab(a);
  const [lb, ab, bb] = toLab(b);
  return Math.hypot(la - lb, aa - ab, ba - bb);
}

/** A shade only joins the palette when it clearly differs from every color already in it. */
const MIN_DIFFERENCE = 28;
const PALETTE_SIZE = 14;

/** The colors in assignment order: the 8 of the picker, then the shades that stand out from them. */
export const DELIVERY_COLORS: readonly string[] = (() => {
  const out: string[] = DELIVERY_BASE_COLORS.map((c) => c.hex);
  const steps = [
    (h: string) => mixColor(h, "#000000", 0.4),
    (h: string) => mixColor(h, "#FFFFFF", 0.45),
    (h: string) => mixColor(h, "#000000", 0.2),
    (h: string) => mixColor(h, "#FFFFFF", 0.25),
  ];
  for (const step of steps) {
    for (const base of DELIVERY_BASE_COLORS) {
      const c = step(base.hex);
      if (out.length < PALETTE_SIZE && out.every((o) => colorDifference(o, c) >= MIN_DIFFERENCE)) out.push(c);
    }
  }
  return out;
})();

/** Default color of the delivery at `index` (0-based); starts over after the last one. */
export function deliveryColorAt(index: number): string {
  const n = DELIVERY_COLORS.length;
  return DELIVERY_COLORS[((index % n) + n) % n];
}

/**
 * Color for a new delivery: the first of the palette that no delivery uses yet, so deleting a
 * delivery and adding another doesn't repeat a color. With every color used, it follows the order.
 */
export function nextDeliveryColor(used: readonly string[]): string {
  const taken = new Set(used.map((c) => c.toUpperCase()));
  return DELIVERY_COLORS.find((c) => !taken.has(c.toUpperCase())) ?? deliveryColorAt(used.length);
}

/** The colors the picker offers (the first 8 of the palette). */
export const PICKER_COLORS = DELIVERY_BASE_COLORS;

/** true when white text/icons over `hex` would be hard to read. */
export function isLightColor(hex: string): boolean {
  return 0.299 * channel(hex, 0) + 0.587 * channel(hex, 1) + 0.114 * channel(hex, 2) > 150;
}

/** Name of a palette color ("Azul CTS"), or the hex when it isn't one. */
export function colorName(hex: string): string {
  return DELIVERY_BASE_COLORS.find((c) => c.hex.toUpperCase() === hex.toUpperCase())?.name ?? hex.toUpperCase();
}

const INK = "#0B1F3A";

/** Color for text or icons over a background of `hex`: white or dark navy, whichever contrasts more (WCAG). */
export function onColor(hex: string): string {
  const lin = (i: number) => {
    const c = channel(hex, i) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  };
  const lum = 0.2126 * lin(0) + 0.7152 * lin(1) + 0.0722 * lin(2);
  const white = 1.05 / (lum + 0.05);
  const ink = (lum + 0.05) / (0.0127 + 0.05); // luminance of #0B1F3A ≈ 0.0127
  return white >= ink ? "#FFFFFF" : INK;
}

const DARK_SURFACE = "#344B73";

function contrast(a: string, b: string): number {
  const lum = (hex: string) => {
    const lin = (i: number) => {
      const c = channel(hex, i) / 255;
      return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
    };
    return 0.2126 * lin(0) + 0.7152 * lin(1) + 0.0722 * lin(2);
  };
  const x = lum(a);
  const y = lum(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

const displayCache = new Map<string, string>();

/**
 * The color to paint a delivery with. In light mode it is the delivery's own color; in dark mode the
 * same color lightened only as much as needed to reach 4.5:1 over the dark surface (and the tinted rows on top of it), so text and
 * shapes stay readable and every place that shows the delivery (strip, badge, name, Gantt bars) uses
 * exactly the same color.
 */
export function displayColor(hex: string, dark: boolean): string {
  if (!dark) return hex;
  const cached = displayCache.get(hex);
  if (cached) return cached;
  let out = hex;
  for (let t = 0; t <= 1 && contrast(out, DARK_SURFACE) < 4.5; t += 0.02) out = mixColor(hex, "#FFFFFF", t);
  displayCache.set(hex, out);
  return out;
}
